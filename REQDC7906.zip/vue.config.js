module.exports = {
  "transpileDependencies": [
    "vuetify"
  ],
}